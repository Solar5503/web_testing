/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.9-MariaDB, for Linux (x86_64)
--
-- Host: production-testrail-data-01.c6xqywhzdx3n.us-east-1.rds.amazonaws.com    Database: testrail-940819
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `ai_credits_balances`
--

DROP TABLE IF EXISTS `ai_credits_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_credits_balances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `balance_type` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `balance` decimal(19,2) NOT NULL DEFAULT '0.00',
  `last_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `next_accrual_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `balance_type` (`balance_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ai_credits_notification_events`
--

DROP TABLE IF EXISTS `ai_credits_notification_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_credits_notification_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `balance_type` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `threshold` int NOT NULL,
  `notified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accrual_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `balance_type` (`balance_type`,`threshold`,`accrual_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ai_credits_transactions`
--

DROP TABLE IF EXISTS `ai_credits_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_credits_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `balance_type` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transaction_type` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` decimal(19,2) NOT NULL,
  `endpoint` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ref_no` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `balance_type` (`balance_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `start_date` int DEFAULT NULL,
  `end_date` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `width` int DEFAULT NULL,
  `view` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `api_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'KEY_STATUS_ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`),
  UNIQUE KEY `unique_api_key` (`api_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `filename` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `filetype` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `cassandra_file_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `size` int NOT NULL,
  `created_on` int NOT NULL,
  `project_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_attachments_cassandra_file_id` (`cassandra_file_id`),
  KEY `ix_attachments_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` bigint NOT NULL,
  `entity_type` tinyint NOT NULL,
  `action_type` tinyint NOT NULL,
  `user_id` int NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `mode` tinyint DEFAULT NULL,
  `entity_name` varchar(256) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `project_name` varchar(2000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `uuid_entity_id` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_log_entity_type_action_type_mode_index` (`entity_type`,`action_type`,`mode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `audit_log_exports`
--

DROP TABLE IF EXISTS `audit_log_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log_exports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` int DEFAULT NULL,
  `created_on` int NOT NULL,
  `filename` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `size` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `banner_id` int unsigned NOT NULL,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `start_date` int DEFAULT NULL,
  `end_date` int DEFAULT NULL,
  `last_reset_cookie_date` int DEFAULT NULL,
  `force_reset_cookie` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_assocs`
--

DROP TABLE IF EXISTS `case_assocs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_assocs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_case_assocs_case_id` (`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_changes`
--

DROP TABLE IF EXISTS `case_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_changes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `type_id` int NOT NULL,
  `created_on` int NOT NULL,
  `user_id` int NOT NULL,
  `changes` longtext COLLATE utf8mb3_unicode_ci,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_case_changes_case_id` (`case_id`),
  KEY `ix_type_id` (`type_id`),
  KEY `fk_case_changes_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_case_changes_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_comments`
--

DROP TABLE IF EXISTS `case_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `change_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_on` int NOT NULL,
  `comment` longtext COLLATE utf8mb3_unicode_ci,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `case_id` (`case_id`),
  KEY `change_id` (`change_id`),
  KEY `ix_case_id_and_change_id` (`case_id`,`change_id`),
  KEY `fk_case_comments_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_case_comments_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_labels`
--

DROP TABLE IF EXISTS `case_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_labels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label_id` int NOT NULL,
  `case_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `case_label` (`case_id`,`label_id`),
  KEY `label_id` (`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_statuses`
--

DROP TABLE IF EXISTS `case_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `short_name` varchar(100) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `display_order` int NOT NULL,
  `is_system` tinyint(1) NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `case_types`
--

DROP TABLE IF EXISTS `case_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `section_id` int NOT NULL,
  `title` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `display_order` int NOT NULL,
  `priority_id` int NOT NULL,
  `estimate` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `custom_preconds` longtext COLLATE utf8mb3_unicode_ci,
  `custom_steps` longtext COLLATE utf8mb3_unicode_ci,
  `custom_expected` longtext COLLATE utf8mb3_unicode_ci,
  `custom_steps_separated` longtext COLLATE utf8mb3_unicode_ci,
  `custom_mission` longtext COLLATE utf8mb3_unicode_ci,
  `custom_goals` longtext COLLATE utf8mb3_unicode_ci,
  `custom_automation_type` int DEFAULT '0',
  `type_id` int NOT NULL,
  `is_copy` tinyint(1) NOT NULL,
  `copyof_id` int DEFAULT NULL,
  `created_on` int NOT NULL,
  `user_id` int NOT NULL,
  `estimate_forecast` int DEFAULT NULL,
  `refs` varchar(2000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `suite_id` int NOT NULL,
  `updated_on` int NOT NULL,
  `updated_by` int NOT NULL,
  `template_id` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status_id` int NOT NULL DEFAULT '1',
  `assigned_to_id` int DEFAULT NULL,
  `custom_testrail_bdd_scenario` longtext COLLATE utf8mb3_unicode_ci,
  `estimate_original_date` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  `ai_generated` tinyint(1) DEFAULT '0',
  `custom_case_is_automated` int DEFAULT '0',
  `custom_case_automation_candidate` int DEFAULT NULL,
  `custom_case_test_data` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ix_cases_section_id` (`section_id`),
  KEY `ix_cases_suite_id` (`suite_id`),
  KEY `ix_cases_copyof_id` (`copyof_id`),
  KEY `status_id` (`status_id`),
  KEY `assigned_to_id` (`assigned_to_id`),
  KEY `ix_cases_created_on` (`created_on`),
  KEY `ix_cases_suite_id_copyof_id` (`suite_id`,`copyof_id`),
  KEY `ix_milestone_id` (`milestone_id`),
  KEY `fk_markdown_editor` (`markdown_editor_id`),
  KEY `ix_cases_refs_is_copy_id` (`refs`(767),`is_copy`,`id`),
  CONSTRAINT `fk_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cases_shared_steps`
--

DROP TABLE IF EXISTS `cases_shared_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases_shared_steps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `shared_step_id` int NOT NULL,
  `created_on` int NOT NULL,
  `updated_on` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_cases_shared_steps_case_id` (`case_id`),
  KEY `ix_cases_shared_steps_shared_step_id` (`shared_step_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config_groups`
--

DROP TABLE IF EXISTS `config_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_config_groups_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `configs`
--

DROP TABLE IF EXISTS `configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_configs_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_project_report_api_templates`
--

DROP TABLE IF EXISTS `cross_project_report_api_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_project_report_api_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `access` int NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `system_options` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_project_report_jobs`
--

DROP TABLE IF EXISTS `cross_project_report_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_project_report_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `executed_on` int DEFAULT NULL,
  `system_options` longtext COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_project_reports`
--

DROP TABLE IF EXISTS `cross_project_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_project_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_ids` varchar(500) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `access` int NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `executed_on` int DEFAULT NULL,
  `execution_time` int DEFAULT NULL,
  `dir` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `formats` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `system_options` longtext COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext COLLATE utf8mb3_unicode_ci,
  `status` int NOT NULL,
  `status_message` longtext COLLATE utf8mb3_unicode_ci,
  `status_trace` longtext COLLATE utf8mb3_unicode_ci,
  `is_locked` tinyint(1) NOT NULL,
  `heartbeat` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_report_api_templates`
--

DROP TABLE IF EXISTS `cross_report_api_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_report_api_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cross_project_api_template_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cross_project_api_template_id_project_id` (`cross_project_api_template_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_report_jobs`
--

DROP TABLE IF EXISTS `cross_report_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_report_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cross_project_job_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cross_project_job_id_project_id` (`cross_project_job_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cross_report_projects`
--

DROP TABLE IF EXISTS `cross_report_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cross_report_projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cross_project_report_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cross_project_report_id_project_id` (`cross_project_report_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datasets`
--

DROP TABLE IF EXISTS `datasets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `datasets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `title` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `data_value` text COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `defects`
--

DROP TABLE IF EXISTS `defects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `defects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `defect_id` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `test_change_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_defects_defect_id` (`defect_id`),
  KEY `ix_defects_test_change_id` (`test_change_id`),
  KEY `ix_defects_case_id` (`case_id`),
  KEY `ix_defects_project_testchange` (`project_id`,`test_change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_notification_template`
--

DROP TABLE IF EXISTS `email_notification_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_notification_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_template` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `email_template_subject` text COLLATE utf8mb3_unicode_ci,
  `email_template_body` text COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_template` (`email_template`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entity_attachments`
--

DROP TABLE IF EXISTS `entity_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entity_id` int unsigned NOT NULL,
  `attachment_id` bigint unsigned NOT NULL,
  `project_id` int DEFAULT NULL,
  `entity_type` varchar(50) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  `is_orphaned` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ix_entity_attachments_attachment_id` (`attachment_id`),
  KEY `ix_entity_attachments_project_id` (`project_id`),
  KEY `attachment_id` (`attachment_id`,`entity_id`),
  KEY `ix_entity_attachments_entity_id_entity_type` (`entity_id`,`entity_type`),
  KEY `idx_entity_attachments_project_id_attachment_id` (`project_id`,`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entity_types`
--

DROP TABLE IF EXISTS `entity_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exports`
--

DROP TABLE IF EXISTS `exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `exports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `size` bigint NOT NULL,
  `created_on` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_exports_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `field_templates`
--

DROP TABLE IF EXISTS `field_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_templates` (
  `field_id` int NOT NULL,
  `template_id` int NOT NULL,
  PRIMARY KEY (`field_id`,`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `system_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `entity_id` int NOT NULL,
  `label` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `type_id` int NOT NULL,
  `location_id` int NOT NULL,
  `display_order` int NOT NULL,
  `configs` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_multi` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `status_id` int NOT NULL,
  `is_system` tinyint(1) NOT NULL,
  `include_all` tinyint(1) NOT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  `ai_field_response_map` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_fields_name` (`entity_id`,`name`),
  KEY `fk_fields_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_fields_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `group_users`
--

DROP TABLE IF EXISTS `group_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_users` (
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `ix_group_users_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jira_oauth`
--

DROP TABLE IF EXISTS `jira_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jira_oauth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `type` int NOT NULL,
  `entity_id` int NOT NULL,
  `feature_type` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `plugin_type` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `association_id` int DEFAULT '-1',
  `url` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `defect_id_url` longtext COLLATE utf8mb3_unicode_ci,
  `defect_add_url` longtext COLLATE utf8mb3_unicode_ci,
  `reference_id_url` longtext COLLATE utf8mb3_unicode_ci,
  `reference_add_url` longtext COLLATE utf8mb3_unicode_ci,
  `access_token` longtext COLLATE utf8mb3_unicode_ci,
  `refresh_token` longtext COLLATE utf8mb3_unicode_ci,
  `access_token_expiry` datetime DEFAULT NULL,
  `refresh_token_expiry` datetime DEFAULT NULL,
  `dc_client_id` longtext COLLATE utf8mb3_unicode_ci,
  `dc_client_secret` longtext COLLATE utf8mb3_unicode_ci,
  `is_saved` int DEFAULT '0',
  `error` longtext COLLATE utf8mb3_unicode_ci,
  `created_by` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_enfe` (`type`,`entity_id`,`feature_type`,`association_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  `is_locked` tinyint(1) NOT NULL,
  `heartbeat` int NOT NULL,
  `is_done` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_jobs_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `markdown_editor`
--

DROP TABLE IF EXISTS `markdown_editor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `markdown_editor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_markdown_editor_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_queue`
--

DROP TABLE IF EXISTS `message_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_queue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `message_id` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `processed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `ix_message_queue_message_id` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_recps`
--

DROP TABLE IF EXISTS `message_recps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_recps` (
  `user_id` int NOT NULL,
  `message_id` int NOT NULL,
  PRIMARY KEY (`message_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `due_on` int DEFAULT NULL,
  `completed_on` int DEFAULT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `start_on` int DEFAULT NULL,
  `started_on` int DEFAULT NULL,
  `is_started` tinyint(1) NOT NULL,
  `parent_id` int DEFAULT NULL,
  `refs` varchar(500) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_milestones_project_id` (`project_id`),
  KEY `ix_milestones_parent_id` (`parent_id`),
  KEY `fk_milestones_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_milestones_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `milestones_refs`
--

DROP TABLE IF EXISTS `milestones_refs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestones_refs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(500) COLLATE utf8mb3_unicode_ci NOT NULL,
  `milestone_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `access_token` varchar(400) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `client_id` varchar(80) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `expires` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `scope` varchar(40) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_token` (`access_token`,`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_authorization_codes`
--

DROP TABLE IF EXISTS `oauth_authorization_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_authorization_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorization_code` varchar(400) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `client_id` varchar(80) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `redirect_uri` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `expires` timestamp NOT NULL,
  `scope` varchar(40) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authorization_code` (`authorization_code`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` varchar(80) COLLATE utf8mb3_unicode_ci NOT NULL,
  `client_secret` varchar(80) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `redirect_uri` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `grant_types` varchar(80) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `scope` varchar(40) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`,`client_secret`,`redirect_uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_connection_tokens`
--

DROP TABLE IF EXISTS `oauth_connection_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_connection_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `access_token` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `refresh_token` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `token_type` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `oauth_connection_server` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `expires_in` int NOT NULL,
  `created_date` int NOT NULL,
  `modified_date` int NOT NULL,
  `oauth_server_region` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`access_token`,`oauth_server_region`,`refresh_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(400) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '',
  `client_id` varchar(80) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `expires` timestamp NOT NULL,
  `created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `scope` varchar(40) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refresh_token` (`refresh_token`,`created_on`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_scopes`
--

DROP TABLE IF EXISTS `oauth_scopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_scopes` (
  `scope` text COLLATE utf8mb3_unicode_ci,
  `is_default` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `otp`
--

DROP TABLE IF EXISTS `otp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `used` tinyint DEFAULT NULL,
  `valid_upto` int DEFAULT NULL,
  `created_date` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pendo_auth`
--

DROP TABLE IF EXISTS `pendo_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pendo_auth` (
  `name` varchar(80) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` varchar(2048) COLLATE utf8mb3_unicode_ci NOT NULL,
  UNIQUE KEY `ux_pendo_auth_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pendo_data`
--

DROP TABLE IF EXISTS `pendo_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pendo_data` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `processed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `phinxlog`
--

DROP TABLE IF EXISTS `phinxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phinxlog` (
  `version` bigint NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_preferences_name` (`user_id`,`name`),
  KEY `ix_preferences_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `priorities`
--

DROP TABLE IF EXISTS `priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `priorities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `priority` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `short_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_access`
--

DROP TABLE IF EXISTS `project_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_access` (
  `project_id` int NOT NULL,
  `user_id` int NOT NULL,
  `access` int NOT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`project_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_assignment`
--

DROP TABLE IF EXISTS `project_assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_assignment` (
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_favs`
--

DROP TABLE IF EXISTS `project_favs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_favs` (
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `created_on` int NOT NULL,
  PRIMARY KEY (`user_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_groups`
--

DROP TABLE IF EXISTS `project_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_groups` (
  `project_id` int NOT NULL,
  `group_id` int NOT NULL,
  `access` int NOT NULL,
  `role_id` int DEFAULT NULL,
  PRIMARY KEY (`project_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_history`
--

DROP TABLE IF EXISTS `project_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `action` int NOT NULL,
  `created_on` int NOT NULL,
  `user_id` int NOT NULL,
  `suite_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `run_id` int DEFAULT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `plan_id` int DEFAULT NULL,
  `case_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_project_history_project_order` (`project_id`,`created_on`),
  KEY `ix_project_history_project_id_run_id` (`project_id`,`run_id`),
  KEY `ix_project_history_project_id_plan_id` (`project_id`,`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_labels`
--

DROP TABLE IF EXISTS `project_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_labels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `name` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`,`name`),
  KEY `created_on` (`created_on`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `announcement` longtext COLLATE utf8mb3_unicode_ci,
  `show_announcement` tinyint(1) NOT NULL,
  `defect_id_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `defect_add_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `default_access` int NOT NULL,
  `default_role_id` int DEFAULT NULL,
  `reference_id_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `reference_add_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `defect_plugin` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `defect_config` longtext COLLATE utf8mb3_unicode_ci,
  `is_completed` tinyint(1) NOT NULL,
  `completed_on` int DEFAULT NULL,
  `defect_template` longtext COLLATE utf8mb3_unicode_ci,
  `suite_mode` int NOT NULL,
  `master_id` int DEFAULT NULL,
  `reference_plugin` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `reference_config` longtext COLLATE utf8mb3_unicode_ci,
  `case_statuses_enabled` tinyint(1) NOT NULL,
  `text_format_type` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT 'plaintext',
  `is_test_case_approval_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `markdown_editor_id` int DEFAULT NULL,
  `ai_enabled` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ix_projects_completed` (`is_completed`),
  KEY `fk_projects_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_projects_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recent_searches`
--

DROP TABLE IF EXISTS `recent_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recent_searches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `query` varchar(4096) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `refs`
--

DROP TABLE IF EXISTS `refs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `refs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `case_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_refs_reference_id` (`reference_id`),
  KEY `ix_refs_case_id` (`case_id`),
  KEY `ix_refs_project_case` (`project_id`,`case_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_api_templates`
--

DROP TABLE IF EXISTS `report_api_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_api_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL,
  `access` int NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `system_options` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ix_report_jobs_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_jobs`
--

DROP TABLE IF EXISTS `report_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `executed_on` int DEFAULT NULL,
  `system_options` longtext COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ix_report_jobs_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plugin` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `access` int NOT NULL,
  `created_by` int NOT NULL,
  `created_on` int NOT NULL,
  `html_executed_on` int DEFAULT NULL,
  `dir` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `formats` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `system_options` longtext COLLATE utf8mb3_unicode_ci,
  `custom_options` longtext COLLATE utf8mb3_unicode_ci,
  `status` int NOT NULL,
  `status_message` longtext COLLATE utf8mb3_unicode_ci,
  `status_trace` longtext COLLATE utf8mb3_unicode_ci,
  `is_locked` tinyint(1) NOT NULL,
  `heartbeat` int NOT NULL,
  `defects_from_most_recent_tests` int DEFAULT '0',
  `markdown_editor_id` int DEFAULT NULL,
  `pdf_status` int DEFAULT '0',
  `pdf_generation_error` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `html_started_on` int DEFAULT NULL,
  `html_finished_on` int DEFAULT NULL,
  `pdf_started_on` int DEFAULT NULL,
  `pdf_finished_on` int DEFAULT NULL,
  `pdf_plugin` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_reports_project_id` (`project_id`),
  KEY `fk_reports_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_reports_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `permissions` bigint NOT NULL,
  `is_default` int NOT NULL,
  `display_order` int NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_project_admin` int NOT NULL DEFAULT '0',
  `can_generate_ai_test_cases` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `run_dynamic_filters`
--

DROP TABLE IF EXISTS `run_dynamic_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `run_dynamic_filters` (
  `run_id` bigint NOT NULL,
  `filters` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runs`
--

DROP TABLE IF EXISTS `runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suite_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `created_on` int NOT NULL,
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `completed_on` int DEFAULT NULL,
  `include_all` tinyint(1) NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `passed_count` int NOT NULL DEFAULT '0',
  `retest_count` int NOT NULL DEFAULT '0',
  `failed_count` int NOT NULL DEFAULT '0',
  `untested_count` int NOT NULL DEFAULT '0',
  `assignedto_id` int DEFAULT NULL,
  `is_plan` tinyint(1) NOT NULL DEFAULT '0',
  `plan_id` int DEFAULT NULL,
  `entry_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `entries` longtext COLLATE utf8mb3_unicode_ci,
  `config` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `config_ids` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `entry_index` int DEFAULT NULL,
  `blocked_count` int NOT NULL DEFAULT '0',
  `is_editable` tinyint(1) NOT NULL,
  `content_id` int DEFAULT NULL,
  `custom_status1_count` int NOT NULL DEFAULT '0',
  `custom_status2_count` int NOT NULL DEFAULT '0',
  `custom_status3_count` int NOT NULL DEFAULT '0',
  `custom_status4_count` int NOT NULL DEFAULT '0',
  `custom_status5_count` int NOT NULL DEFAULT '0',
  `custom_status6_count` int NOT NULL DEFAULT '0',
  `custom_status7_count` int NOT NULL DEFAULT '0',
  `updated_by` int NOT NULL,
  `updated_on` int NOT NULL,
  `refs` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `dataset_id` int DEFAULT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  `run_start_on` int DEFAULT NULL,
  `run_due_on` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_runs_project_id` (`project_id`),
  KEY `ix_runs_plan_id` (`plan_id`),
  KEY `ix_runs_milestone_id` (`milestone_id`),
  KEY `ix_runs_suite_id` (`suite_id`),
  KEY `ix_runs_project_id_is_plan` (`project_id`,`is_plan`),
  KEY `ix_runs_suite_id_is_completed` (`suite_id`,`is_completed`,`plan_id`),
  KEY `fk_runs_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_runs_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `runs_refs`
--

DROP TABLE IF EXISTS `runs_refs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `runs_refs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_id` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `run_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `saml_assertions`
--

DROP TABLE IF EXISTS `saml_assertions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saml_assertions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `assertion_id` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_saml_assertions_assertion_id` (`assertion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suite_id` int DEFAULT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `display_order` int NOT NULL,
  `is_copy` tinyint(1) NOT NULL,
  `copyof_id` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `depth` int NOT NULL DEFAULT '0',
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_sections_suite_id` (`suite_id`),
  KEY `ix_sections_copyof_id` (`copyof_id`),
  KEY `ix_sections_parent_id` (`parent_id`),
  KEY `fk_sections_markdown_editor` (`markdown_editor_id`),
  KEY `ix_sections_is_copy` (`is_copy`),
  KEY `idx_sections_suite_copy_id` (`suite_id`,`is_copy`,`copyof_id`,`id`),
  CONSTRAINT `fk_sections_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(40) COLLATE utf8mb3_unicode_ci NOT NULL,
  `ip_address` varchar(16) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_agent` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  `user_data` longtext COLLATE utf8mb3_unicode_ci,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_invalidated` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sessions_session_id` (`session_id`),
  KEY `ix_user_id_is_invalidated` (`user_id`,`is_invalidated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_settings_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shared_step_changes`
--

DROP TABLE IF EXISTS `shared_step_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_step_changes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shared_step_id` int NOT NULL,
  `version` int NOT NULL,
  `type_id` int NOT NULL,
  `created_on` int NOT NULL,
  `updated_by` int NOT NULL,
  `changes` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `ix_shared_step_changes_shared_step_id` (`shared_step_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shared_step_elements`
--

DROP TABLE IF EXISTS `shared_step_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_step_elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shared_step_id` int NOT NULL,
  `display_order` int NOT NULL,
  `content` longtext COLLATE utf8mb3_unicode_ci,
  `additional_info` longtext COLLATE utf8mb3_unicode_ci,
  `expected` longtext COLLATE utf8mb3_unicode_ci,
  `refs` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_on` int NOT NULL,
  `updated_on` int NOT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_shared_step_elements_shared_step_id` (`shared_step_id`),
  KEY `fk_shared_step_elements_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_shared_step_elements_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shared_steps`
--

DROP TABLE IF EXISTS `shared_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shared_steps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `title` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  `updated_on` int NOT NULL,
  `created_by` int NOT NULL,
  `updated_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_shared_steps_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_settings`
--

DROP TABLE IF EXISTS `sso_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sso_integration_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `testrail_entity_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sso_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `idp_sso_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `idp_issuer_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `ssl_certificate` longtext COLLATE utf8mb3_unicode_ci,
  `saml_encryption_private_key` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sso_integration_name` (`sso_integration_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_settings_oauth`
--

DROP TABLE IF EXISTS `sso_settings_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_settings_oauth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sso_configuration` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `oauth_client_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `oauth_client_secret` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `oauth_issuer_uri` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `oauth_user_auth_uri` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `oauth_user_info_uri` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `oauth_create_account_on_first_login` int DEFAULT '1',
  `oauth_whitelist_domains` text COLLATE utf8mb3_unicode_ci,
  `oauth_sso_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sso_configuration_oauth` (`sso_configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_settings_openid`
--

DROP TABLE IF EXISTS `sso_settings_openid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_settings_openid` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sso_configuration` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `client_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_secret` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `issuer_uri` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `openid_create_account_on_first_login` int DEFAULT '1',
  `whitelist_domains` text COLLATE utf8mb3_unicode_ci,
  `sso_url` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_sso_configuration_openid` (`sso_configuration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `system_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `label` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `color_dark` int NOT NULL,
  `color_medium` int NOT NULL,
  `color_bright` int NOT NULL,
  `display_order` int NOT NULL,
  `is_system` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_untested` tinyint(1) NOT NULL,
  `is_final` tinyint(1) NOT NULL,
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `is_notapplicable` int DEFAULT '0',
  `is_executed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_statuses_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `is_subscribed` tinyint(1) NOT NULL,
  `test_id` int NOT NULL,
  `run_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_subscriptions_run_test` (`run_id`,`test_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `suites`
--

DROP TABLE IF EXISTS `suites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `project_id` int NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `created_on` int NOT NULL,
  `created_by` int NOT NULL,
  `is_copy` tinyint(1) NOT NULL,
  `copyof_id` int DEFAULT NULL,
  `is_master` tinyint(1) NOT NULL,
  `is_baseline` tinyint(1) NOT NULL,
  `parent_id` int DEFAULT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `completed_on` int DEFAULT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_suites_project_id` (`project_id`),
  KEY `ix_suites_copyof_id` (`copyof_id`),
  KEY `fk_suites_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_suites_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task` (
  `id` int NOT NULL,
  `is_locked` tinyint(1) NOT NULL,
  `heartbeat` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `template_projects`
--

DROP TABLE IF EXISTS `template_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_projects` (
  `template_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`template_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `include_all` tinyint(1) NOT NULL,
  `is_editable` tinyint(1) DEFAULT '1',
  `is_removable` tinyint(1) DEFAULT '1',
  `i18n_custom_id` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_activities`
--

DROP TABLE IF EXISTS `test_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_activities` (
  `date` int NOT NULL,
  `project_id` int NOT NULL,
  `run_id` int NOT NULL,
  `passed_count` int NOT NULL,
  `retest_count` int NOT NULL,
  `failed_count` int NOT NULL,
  `untested_count` int NOT NULL,
  `blocked_count` int NOT NULL,
  `custom_status1_count` int NOT NULL,
  `custom_status2_count` int NOT NULL,
  `custom_status3_count` int NOT NULL,
  `custom_status4_count` int NOT NULL,
  `custom_status5_count` int NOT NULL,
  `custom_status6_count` int NOT NULL,
  `custom_status7_count` int NOT NULL,
  PRIMARY KEY (`date`,`project_id`,`run_id`),
  KEY `ix_test_activities_run_id` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_assocs`
--

DROP TABLE IF EXISTS `test_assocs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_assocs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_change_id` int NOT NULL,
  `test_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_test_assocs_test_change_id` (`test_change_id`),
  KEY `ix_test_assocs_test_id` (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_changes`
--

DROP TABLE IF EXISTS `test_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_changes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_id` int NOT NULL,
  `user_id` int NOT NULL,
  `status_id` int DEFAULT NULL,
  `comment` longtext COLLATE utf8mb3_unicode_ci,
  `version` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `elapsed` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `defects` varchar(2000) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_on` int NOT NULL,
  `assignedto_id` int DEFAULT NULL,
  `unassigned` tinyint(1) NOT NULL,
  `project_id` int NOT NULL,
  `run_id` int NOT NULL,
  `is_selected` tinyint(1) NOT NULL,
  `caching` int NOT NULL,
  `custom_step_results` longtext COLLATE utf8mb3_unicode_ci,
  `custom_testrail_bdd_scenario_results` longtext COLLATE utf8mb3_unicode_ci,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_test_changes_test_id` (`test_id`),
  KEY `ix_test_changes_project_order` (`project_id`,`is_selected`,`created_on`),
  KEY `ix_test_changes_run_order` (`run_id`,`is_selected`,`created_on`),
  KEY `ix_test_changes_selected_elapsed` (`test_id`,`is_selected`,`elapsed`),
  KEY `ix_test_changes_run_id_is_selected_status_id` (`run_id`,`is_selected`,`status_id`),
  KEY `fk_test_changes_markdown_editor` (`markdown_editor_id`),
  KEY `ix_test_changes_defects_id` (`defects`(767),`id`),
  CONSTRAINT `fk_test_changes_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_labels`
--

DROP TABLE IF EXISTS `test_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_labels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label_id` int NOT NULL,
  `test_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `test_label` (`test_id`,`label_id`),
  KEY `label_id` (`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_progress`
--

DROP TABLE IF EXISTS `test_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_progress` (
  `date` int NOT NULL,
  `project_id` int NOT NULL,
  `run_id` int NOT NULL,
  `tests` int NOT NULL,
  `forecasts` int NOT NULL,
  PRIMARY KEY (`date`,`project_id`,`run_id`),
  KEY `ix_test_progress_run_id` (`run_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_results_import_jobs`
--

DROP TABLE IF EXISTS `test_results_import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_results_import_jobs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `assignedto_id` int NOT NULL,
  `plan_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `automation_type` int DEFAULT NULL,
  `file` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_running` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_timers`
--

DROP TABLE IF EXISTS `test_timers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_timers` (
  `test_id` int NOT NULL,
  `user_id` int NOT NULL,
  `started_on` int NOT NULL,
  `elapsed` int NOT NULL,
  `is_paused` tinyint(1) NOT NULL,
  PRIMARY KEY (`test_id`,`user_id`),
  KEY `ix_test_timers_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `run_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `status_id` int NOT NULL,
  `assignedto_id` int DEFAULT NULL,
  `is_selected` tinyint(1) NOT NULL,
  `last_status_change_id` int DEFAULT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `in_progress` int NOT NULL,
  `in_progress_by` int DEFAULT NULL,
  `content_id` int DEFAULT NULL,
  `tested_by` int DEFAULT NULL,
  `tested_on` int DEFAULT NULL,
  `added_dynamic` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ix_tests_run_id` (`run_id`),
  KEY `ix_tests_case_id` (`case_id`,`is_selected`),
  KEY `ix_tests_content_id` (`content_id`),
  KEY `ix_test_run_case` (`run_id`,`case_id`),
  KEY `ix_test_runs_status_selected` (`run_id`,`is_selected`,`status_id`),
  KEY `ix_tests_assignedto_id_is_selected_status_id` (`assignedto_id`,`is_selected`,`status_id`,`run_id`),
  KEY `ix_tests_run_id_case_id` (`run_id`,`case_id`,`status_id`,`is_selected`),
  KEY `ix_tests_assignedto_id` (`assignedto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uiscripts`
--

DROP TABLE IF EXISTS `uiscripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `uiscripts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `includes` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `excludes` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `meta` longtext COLLATE utf8mb3_unicode_ci,
  `js` longtext COLLATE utf8mb3_unicode_ci,
  `css` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_columns`
--

DROP TABLE IF EXISTS `user_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_columns` (
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `area_id` int NOT NULL,
  `columns` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_by` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `group_order` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`project_id`,`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_exports`
--

DROP TABLE IF EXISTS `user_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_exports` (
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `area_id` int NOT NULL,
  `format` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `options` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`project_id`,`area_id`,`format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_fields`
--

DROP TABLE IF EXISTS `user_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `system_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `label` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb3_unicode_ci,
  `type_id` int NOT NULL,
  `fallback` varchar(750) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `markdown_editor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_user_fields_name` (`name`),
  KEY `fk_user_fields_markdown_editor` (`markdown_editor_id`),
  CONSTRAINT `fk_user_fields_markdown_editor` FOREIGN KEY (`markdown_editor_id`) REFERENCES `markdown_editor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_filters`
--

DROP TABLE IF EXISTS `user_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_filters` (
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `area_id` int NOT NULL,
  `filters` longtext COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`project_id`,`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_logins`
--

DROP TABLE IF EXISTS `user_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_logins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  `updated_on` int NOT NULL,
  `attempts` int NOT NULL,
  `mfa_attempts` int NOT NULL DEFAULT '0',
  `mfa_updated_on` int NOT NULL DEFAULT '0',
  `current_auth` varchar(10) COLLATE utf8mb3_unicode_ci DEFAULT 'local',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_user_logins_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_user_settings_name` (`user_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_tokens`
--

DROP TABLE IF EXISTS `user_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type_id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `series` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hash` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_on` int NOT NULL,
  `expires_on` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_user_tokens_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `salt` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `hash` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `rememberme` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `locale` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `language` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `notifications` tinyint(1) NOT NULL,
  `csrf` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `role_id` int NOT NULL,
  `login_token` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `timezone` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `login_token_until` int DEFAULT NULL,
  `last_activity` int DEFAULT NULL,
  `is_reset_password_forced` tinyint(1) NOT NULL DEFAULT '0',
  `data_processing_agreement` longtext COLLATE utf8mb3_unicode_ci,
  `theme` int DEFAULT '0',
  `is_bdd_autocomplete_enabled` tinyint(1) DEFAULT '0',
  `is_mfa_enabled` int DEFAULT '0',
  `auth_app_connected` int DEFAULT '0',
  `mfa_secret` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password_reset_token_until` int DEFAULT NULL,
  `is_sso_enabled` int DEFAULT '0',
  `is_fallback_password_set` int DEFAULT '1',
  `forgot_password_attempts` int NOT NULL DEFAULT '0',
  `forgot_password_attempt_on` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `variables`
--

DROP TABLE IF EXISTS `variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `variables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `variable_name` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `variable_name` (`variable_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webhook_deliveries`
--

DROP TABLE IF EXISTS `webhook_deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_deliveries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` varchar(50) NOT NULL,
  `hook_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `request_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `state` varchar(3) DEFAULT '404',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webhook_projects`
--

DROP TABLE IF EXISTS `webhook_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_projects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hook_id` int NOT NULL,
  `project_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `hook_id` varchar(50) NOT NULL,
  `webhook_name` varchar(300) NOT NULL,
  `payload_url` varchar(300) NOT NULL,
  `method` varchar(10) NOT NULL,
  `content_type` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `request_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `state` varchar(3) DEFAULT '404',
  `secret` varchar(100) DEFAULT NULL,
  `events` text,
  `projects` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attempt` int NOT NULL DEFAULT '0',
  `retry_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-01-12 19:50:50
